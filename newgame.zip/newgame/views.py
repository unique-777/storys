from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from transformers import pipeline
import re

# Initialize the text-generation pipeline
generator = pipeline('text-generation', model='gpt2')

def generate_chunk(prompt_text, max_len):
    results = generator(
        prompt_text,
        max_length=max_len,
        temperature=0.9,
        top_p=0.95,
        top_k=40,
        repetition_penalty=1.2,
        do_sample=True,
        num_return_sequences=3,
        pad_token_id=generator.tokenizer.eos_token_id,
        truncation=True,
    )

    def clean_story(text):
        story = text[len(prompt_text):].strip()
        story = re.sub(r'^[^A-Z]*', '', story)
        story = re.sub(r'\s+', ' ', story)  # Normalize spacing
        last_punct = max(story.rfind('.'), story.rfind('!'), story.rfind('?'))
        if last_punct != -1:
            story = story[:last_punct + 1]
        return story.strip()

    cleaned = [clean_story(res['generated_text']) for res in results]
    return max(cleaned, key=len, default="")

def generate_story(mood, theme):
    # Strong narrative-driven prompts
    intro_prompt = (
        f"Write a {mood} short story about {theme} with a magical beginning.\n"
        f"Begin the story with: 'Once upon a time, in a world where {theme} mattered most, there lived...'\n"
        f"Start the story:"
    )
    intro = generate_chunk(intro_prompt, max_len=250)

    middle_prompt = (
        f"The story becomes more emotional and deep. Describe what challenges or turning points arise.\n"
        f"{intro}\n\nThen something unexpected happened:"
    )
    middle = generate_chunk(middle_prompt, max_len=300)

    end_prompt = (
        f"End the {mood} story with a reflective and meaningful conclusion that teaches a lesson.\n"
        f"{intro}\n\n{middle}\n\nFinally, the story ends like this:"
    )
    ending = generate_chunk(end_prompt, max_len=300)

    full_story = f"{intro}\n\n{middle}\n\n{ending}".strip()
    full_story = re.sub(r'\n+', '\n', full_story)

    # Add punctuation if missing
    if not full_story[-1] in '.!?':
        full_story += '.'

    if len(full_story) < 300:
        return "Sorry, I couldn't generate a complete story this time. Please try again with a different mood or theme."

    return full_story

@csrf_exempt
def generate_story_view(request):
    if request.method == 'POST':
        mood = request.POST.get('mood')
        theme = request.POST.get('theme')

        if not mood or not theme:
            return JsonResponse({"error": "Mood or theme is missing."}, status=400)

        try:
            story = generate_story(mood.strip().lower(), theme.strip().lower())
            return JsonResponse({"story": story})
        except Exception as e:
            return JsonResponse({"error": f"Server error: {str(e)}"}, status=500)

    return JsonResponse({"error": "Invalid request method."}, status=405)

def home(request):
    return render(request, 'newgame/index.html')