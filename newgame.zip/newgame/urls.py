from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('generate-story/', views.generate_story_view, name='generate_story'),
]
